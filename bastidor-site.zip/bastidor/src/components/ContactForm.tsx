"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { whatsappLink } from "@/content/site";
import { ChatIcon } from "./ChatIcon";

const channels = ["WhatsApp", "Instagram", "E-mail", "Comunidade/plataforma"];

/**
 * Formulário sem servidor: monta uma mensagem organizada e abre o WhatsApp
 * com ela pronta. Depois leva o visitante à página de agradecimento.
 */
export function ContactForm() {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("nome") || "").trim();
    const product = String(data.get("produto") || "").trim();
    const platform = String(data.get("plataforma") || "").trim();
    const picked = data.getAll("canais").map(String);
    const message = String(data.get("mensagem") || "").trim();

    const next: Record<string, string> = {};
    if (!name) next.nome = "Escreva seu nome para eu saber com quem estou falando.";
    if (!product) next.produto = "Conte o que você vende, mesmo que em poucas palavras.";
    setErrors(next);
    if (Object.keys(next).length) {
      document.getElementById(next.nome ? "f-nome" : "f-produto")?.focus();
      return;
    }

    const lines = [
      `Olá! Meu nome é ${name}.`,
      `Produto: ${product}`,
      platform && `Plataforma: ${platform}`,
      picked.length > 0 && `Canais de atendimento: ${picked.join(", ")}`,
      message && `\n${message}`,
      "\nQuero conversar sobre suporte para o meu infoproduto.",
    ].filter(Boolean);
    const link = whatsappLink(lines.join("\n"));

    try {
      sessionStorage.setItem("bastidor:wa", link);
    } catch {}
    window.open(link, "_blank", "noopener");
    router.push("/obrigado/");
  }

  const err = (key: string) =>
    errors[key] ? (
      <p id={`e-${key}`} className="mt-2 text-sm text-[#ffb3ba]">
        {errors[key]}
      </p>
    ) : null;

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div>
        <label htmlFor="f-nome" className="mb-2 block text-sm font-medium text-white/85">Seu nome</label>
        <input id="f-nome" name="nome" autoComplete="name" className="field" aria-invalid={!!errors.nome} aria-describedby={errors.nome ? "e-nome" : undefined} />
        {err("nome")}
      </div>
      <div>
        <label htmlFor="f-produto" className="mb-2 block text-sm font-medium text-white/85">O que você vende</label>
        <input id="f-produto" name="produto" placeholder="Ex.: curso online de fotografia" className="field" aria-invalid={!!errors.produto} aria-describedby={errors.produto ? "e-produto" : undefined} />
        {err("produto")}
      </div>
      <div>
        <label htmlFor="f-plataforma" className="mb-2 block text-sm font-medium text-white/85">
          Plataforma <span className="font-normal text-white/55">(opcional)</span>
        </label>
        <input id="f-plataforma" name="plataforma" placeholder="Ex.: Hotmart, Kiwify, Eduzz" className="field" />
      </div>
      <fieldset>
        <legend className="mb-3 text-sm font-medium text-white/85">Onde chegam as mensagens</legend>
        <div className="flex flex-wrap gap-2">
          {channels.map((c) => (
            <label key={c} className="cursor-pointer">
              <input type="checkbox" name="canais" value={c} className="peer sr-only" />
              <span className="inline-flex min-h-11 items-center rounded-full border border-white/25 px-4 text-[0.95rem] text-white/85 transition-colors peer-checked:border-white peer-checked:bg-white peer-checked:text-ink peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-white">
                {c}
              </span>
            </label>
          ))}
        </div>
      </fieldset>
      <div>
        <label htmlFor="f-msg" className="mb-2 block text-sm font-medium text-white/85">
          Algo mais que eu deva saber <span className="font-normal text-white/55">(opcional)</span>
        </label>
        <textarea id="f-msg" name="mensagem" rows={3} placeholder="Ex.: tenho um lançamento em março e as mensagens triplicam" className="field resize-y" />
      </div>
      <button type="submit" className="btn btn-primary w-full sm:w-auto">
        <ChatIcon />
        Abrir no WhatsApp
      </button>
    </form>
  );
}
