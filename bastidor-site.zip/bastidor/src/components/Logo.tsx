/** Marca: um bastidor (aro de bordado) com um ponto de costura em vermelho. */
export function LogoMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={className}>
      <circle cx="16" cy="17" r="12" fill="none" stroke="currentColor" strokeWidth="2.6" />
      <rect x="13.5" y="2.5" width="5" height="4" rx="1" fill="currentColor" />
      <path d="M9 17h3.2M14.4 17h3.2M19.8 17H23" stroke="#b8323f" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ name }: { name: string }) {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark className="h-7 w-7 text-ink" />
      <span className="font-serif text-[1.45rem] leading-none tracking-[-0.01em] translate-y-[1px]">{name}</span>
    </span>
  );
}
