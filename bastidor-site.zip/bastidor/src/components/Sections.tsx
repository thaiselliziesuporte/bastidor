import { about, differentials, faq, finalCta, hero, method, portfolio, problem, services } from "@/content/content";
import { site, whatsappLink } from "@/content/site";
import { ChatIcon } from "./ChatIcon";
import { ContactForm } from "./ContactForm";
import { Faq } from "./Faq";
import { HoopArt } from "./HoopArt";

const wrap = "mx-auto max-w-6xl px-5 sm:px-8";

function SectionTitle({ children, id, className = "" }: { children: React.ReactNode; id?: string; className?: string }) {
  return (
    <h2 id={id} className={`display text-[2.35rem] sm:text-[3.1rem] lg:text-[3.5rem] ${className}`}>
      {children}
    </h2>
  );
}

/* ---------------------------------------------------------------- HERO */
export function Hero() {
  return (
    <section id="topo" className="pt-[6.5rem] sm:pt-32 lg:pt-36">
      <div className={`${wrap} grid items-center gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16`}>
        <div>
          <h1 className="display max-w-[14ch] text-[2.9rem] sm:text-[4.4rem] lg:text-[5rem]">{hero.headline}</h1>
          <p className="mt-6 max-w-[52ch] text-[1.1rem] leading-relaxed text-muted sm:mt-8 sm:text-[1.2rem]">{hero.subheadline}</p>
          <div className="mt-8 flex flex-col gap-3 sm:mt-10 sm:flex-row">
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              <ChatIcon />
              {hero.primaryCta}
            </a>
            <a href="#como-funciona" className="btn btn-ghost">
              {hero.secondaryCta}
            </a>
          </div>
          <p className="mt-4 text-sm text-muted">{hero.note}</p>
        </div>
        <div className="mx-auto w-full max-w-[260px] sm:max-w-[360px] lg:max-w-[440px]">
          <HoopArt className="h-auto w-full" />
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------- PROBLEMA */
export function Problem() {
  return (
    <section aria-labelledby="t-problema" className="py-24 sm:py-32">
      <div className={`${wrap} grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20`}>
        <div className="lg:sticky lg:top-28 lg:self-start">
          <SectionTitle id="t-problema">{problem.title}</SectionTitle>
          <p className="mt-6 max-w-[46ch] text-muted">{problem.intro}</p>
        </div>
        <div>
          <ul className="space-y-9">
            {problem.items.map((item) => (
              <li key={item.message}>
                <p className="inline-block rounded-2xl rounded-bl-[4px] bg-surface px-5 py-3.5 font-serif text-[1.3rem] leading-snug shadow-[0_1px_0_var(--color-line)] sm:text-[1.45rem]">
                  {item.message}
                </p>
                <p className="mt-3 max-w-[50ch] pl-1 text-muted">{item.context}</p>
              </li>
            ))}
          </ul>
          <p className="display mt-14 border-t border-line pt-10 text-[1.7rem] text-ink sm:text-[2.1rem]">{problem.closing}</p>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------- SERVIÇOS */
export function Services() {
  return (
    <section id="servicos" aria-labelledby="t-servicos" className="bg-surface py-24 sm:py-32">
      <div className={wrap}>
        <div className="max-w-3xl">
          <SectionTitle id="t-servicos">{services.title}</SectionTitle>
          <p className="mt-6 max-w-[58ch] text-muted">{services.intro}</p>
        </div>
        <div className="mt-14 grid gap-x-16 sm:grid-cols-2">
          {services.items.map((s) => (
            <article key={s.title} className="border-t border-ink/80 py-9">
              <h3 className="font-serif text-[1.75rem] leading-tight">{s.title}</h3>
              <p className="mt-3 max-w-[48ch] text-muted">{s.description}</p>
              <ul className="mt-6 space-y-2.5">
                {s.includes.map((inc) => (
                  <li key={inc} className="flex gap-3">
                    <span aria-hidden="true" className="mt-[0.8em] h-[2px] w-3 shrink-0 bg-thread" />
                    <span>{inc}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* --------------------------------------------------------------- MÉTODO */
export function Method() {
  return (
    <section id="como-funciona" aria-labelledby="t-metodo" className="py-24 sm:py-32">
      <div className={wrap}>
        <div className="max-w-3xl">
          <SectionTitle id="t-metodo">{method.title}</SectionTitle>
          <p className="mt-6 max-w-[52ch] text-muted">{method.intro}</p>
        </div>
        <ol className="relative mt-16 grid gap-12 lg:grid-cols-4 lg:gap-10">
          {/* linha de costura que liga as etapas */}
          <span aria-hidden="true" className="absolute bottom-6 left-[1.35rem] top-6 border-l-2 border-dashed border-thread/60 lg:hidden" />
          <span aria-hidden="true" className="absolute left-6 right-6 top-[1.35rem] hidden border-t-2 border-dashed border-thread/60 lg:block" />
          {method.steps.map((step, i) => (
            <li key={step.title} className="relative grid grid-cols-[2.75rem_1fr] gap-5 lg:block">
              <span className="relative z-10 flex h-11 w-11 items-center justify-center rounded-full border-2 border-thread bg-paper font-serif text-lg text-thread">
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="lg:mt-7">
                <h3 className="font-serif text-[1.6rem] leading-tight">{step.title}</h3>
                <p className="mt-3 text-muted">{step.description}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* --------------------------------------------------------- DIFERENCIAIS */
export function Differentials() {
  return (
    <section aria-labelledby="t-dif" className="bg-ink py-24 text-white sm:py-32">
      <div className={wrap}>
        <SectionTitle id="t-dif" className="max-w-[18ch]">{differentials.title}</SectionTitle>
        <div className="mt-14 grid gap-x-16 gap-y-12 md:grid-cols-2">
          {differentials.items.map((d) => (
            <div key={d.title} className="border-l-2 border-thread pl-6">
              <h3 className="font-serif text-[1.65rem] leading-tight">{d.title}</h3>
              <p className="mt-3 max-w-[50ch] text-white/75">{d.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------------------- PORTFÓLIO / DEMONSTRAÇÃO */
function PlaybookDemo() {
  return (
    <figure className="rounded-2xl border border-line bg-surface p-6 sm:p-8">
      <figcaption className="flex items-baseline justify-between gap-4 border-b border-line pb-4">
        <span className="font-serif text-xl">Manual de respostas</span>
        <span className="text-sm text-muted">trecho</span>
      </figcaption>
      <dl className="mt-6 space-y-6 text-[0.98rem]">
        <div>
          <dt className="font-semibold">Quando o aluno diz que não recebeu o acesso</dt>
          <dd className="mt-2 text-muted">
            Confirmar o e-mail da compra, verificar na plataforma e reenviar o acesso. Responder no tom da marca:
          </dd>
          <dd className="mt-3 rounded-xl rounded-bl-[4px] bg-paper px-4 py-3 font-serif text-[1.08rem] leading-snug">
            Oi, Marina! Já encontrei sua compra e reenviei o acesso para o seu e-mail agora. Me avisa se chegou?
          </dd>
        </div>
        <div>
          <dt className="font-semibold">Quando encaminhar para você</dt>
          <dd className="mt-2 text-muted">Pedidos de parceria, imprensa e qualquer reembolso fora da política.</dd>
        </div>
      </dl>
    </figure>
  );
}

function ReportDemo() {
  const rows = [
    { label: "Acesso e senha", w: "78%" },
    { label: "Dúvidas de compra", w: "56%" },
    { label: "Navegação na plataforma", w: "40%" },
    { label: "Certificado", w: "18%" },
  ];
  return (
    <figure className="rounded-2xl border border-line bg-surface p-6 sm:p-8">
      <figcaption className="flex items-baseline justify-between gap-4 border-b border-line pb-4">
        <span className="font-serif text-xl">Relatório do período</span>
        <span className="text-sm text-muted">modelo</span>
      </figcaption>
      <p className="mt-6 font-semibold">Assuntos que mais se repetiram</p>
      <ul className="mt-4 space-y-4">
        {rows.map((r) => (
          <li key={r.label}>
            <span className="text-[0.95rem] text-muted">{r.label}</span>
            <span className="mt-1.5 block h-2 rounded-full bg-paper">
              <span className="block h-2 rounded-full bg-ink" style={{ width: r.w }} />
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-7 font-semibold">Sugestão de melhoria</p>
      <p className="mt-2 text-[0.98rem] text-muted">
        Incluir na página de obrigado o passo a passo do primeiro acesso, para reduzir as dúvidas mais frequentes.
      </p>
    </figure>
  );
}

export function Portfolio() {
  const hasCases = portfolio.cases.length > 0;
  return (
    <section id="demonstracao" aria-labelledby="t-port" className="py-24 sm:py-32">
      <div className={wrap}>
        <div className="max-w-3xl">
          <SectionTitle id="t-port">{hasCases ? "Trabalhos realizados" : portfolio.title}</SectionTitle>
          {!hasCases && <p className="mt-6 max-w-[56ch] text-muted">{portfolio.intro}</p>}
        </div>

        {hasCases ? (
          <div className="mt-14 grid gap-6 md:grid-cols-2">
            {portfolio.cases.map((c) => (
              <article key={c.client} className="rounded-2xl border border-line bg-surface p-7 sm:p-9">
                <p className="text-sm text-muted">{c.segment}</p>
                <h3 className="mt-1 font-serif text-[1.7rem] leading-tight">{c.client}</h3>
                <dl className="mt-6 space-y-4">
                  {[
                    ["Antes", c.challenge],
                    ["O que foi feito", c.work],
                    ["Resultado", c.result],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <dt className="font-semibold">{k}</dt>
                      <dd className="mt-1 text-muted">{v}</dd>
                    </div>
                  ))}
                </dl>
              </article>
            ))}
          </div>
        ) : (
          <>
            <div className="mt-14 grid gap-6 lg:grid-cols-2">
              <PlaybookDemo />
              <ReportDemo />
            </div>
            <p className="mt-6 text-sm text-muted">{portfolio.disclaimer}</p>
          </>
        )}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------- SOBRE */
export function About() {
  return (
    <section id="sobre" aria-labelledby="t-sobre" className="bg-surface py-24 sm:py-32">
      <div className={`${wrap} grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20`}>
        <div className="flex flex-col items-start">
          <div className="relative aspect-square w-48 sm:w-64">
            <span aria-hidden="true" className="absolute inset-0 rounded-full border-[10px] border-ink" />
            <span aria-hidden="true" className="absolute left-1/2 top-[-14px] h-6 w-9 -translate-x-1/2 rounded-md bg-ink" />
            <div className="absolute inset-[16px] overflow-hidden rounded-full bg-paper">
              {site.ownerPhoto ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={site.ownerPhoto} alt={`Foto de ${site.ownerName}`} className="h-full w-full object-cover" />
              ) : (
                <span className="flex h-full w-full items-center justify-center font-serif text-6xl text-ink sm:text-7xl" aria-hidden="true">
                  {site.ownerInitials}
                </span>
              )}
            </div>
          </div>
          <p className="mt-8 font-serif text-[1.6rem] leading-tight">{site.ownerName}</p>
          <p className="text-muted">Suporte e atendimento para infoprodutores</p>
        </div>
        <div>
          <SectionTitle id="t-sobre">{about.title}</SectionTitle>
          <div className="mt-8 max-w-[60ch] space-y-5 text-[1.08rem]">
            {about.paragraphs.map((p) => (
              <p key={p.slice(0, 24)}>{p}</p>
            ))}
          </div>
          <h3 className="mt-12 font-semibold">Formação e certificações</h3>
          <ul className="mt-4 grid gap-x-10 border-t border-line sm:grid-cols-2">
            {about.credentials.map((c) => (
              <li key={c} className="border-b border-line py-3 text-muted">
                {c}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ FAQ */
export function FaqSection() {
  return (
    <section id="duvidas" aria-labelledby="t-faq" className="py-24 sm:py-32">
      <div className={`${wrap} grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20`}>
        <div>
          <SectionTitle id="t-faq">{faq.title}</SectionTitle>
          <p className="mt-6 max-w-[38ch] text-muted">
            Não encontrou sua dúvida?{" "}
            <a href={whatsappLink("Olá! Tenho uma dúvida sobre o seu serviço de suporte:")} target="_blank" rel="noopener noreferrer" className="text-ink underline decoration-thread decoration-2 underline-offset-4 hover:text-thread">
              Pergunte pelo WhatsApp
            </a>
            .
          </p>
        </div>
        <Faq items={faq.items} />
      </div>
    </section>
  );
}

/* ------------------------------------------------------------ CTA FINAL */
export function FinalCta() {
  return (
    <section id="contato" aria-labelledby="t-cta" className="bg-ink py-24 text-white sm:py-32">
      <div className={`${wrap} grid gap-14 lg:grid-cols-2 lg:gap-20`}>
        <div>
          <SectionTitle id="t-cta" className="max-w-[14ch]">{finalCta.title}</SectionTitle>
          <p className="mt-6 max-w-[46ch] text-white/75">{finalCta.text}</p>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-9 w-full sm:w-auto">
            <ChatIcon />
            {finalCta.button}
          </a>
        </div>
        <div className="rounded-3xl border border-white/15 p-6 sm:p-9">
          <h3 className="font-serif text-[1.6rem] leading-tight">{finalCta.formTitle}</h3>
          <p className="mb-7 mt-2 text-white/70">{finalCta.formText}</p>
          <ContactForm />
        </div>
      </div>
    </section>
  );
}

/* --------------------------------------------------------------- RODAPÉ */
export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-ink pb-10 text-white/70">
      <div className={`${wrap} flex flex-col gap-4 border-t border-white/15 pt-8 text-sm sm:flex-row sm:items-center sm:justify-between`}>
        <p>
          <span className="font-serif text-lg text-white">{site.brand}</span>
          <span className="ml-3">{site.tagline}</span>
        </p>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          <span>{site.location}</span>
          {site.email && (
            <a href={`mailto:${site.email}`} className="hover:text-white">
              {site.email}
            </a>
          )}
          {site.instagram && (
            <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-white">
              Instagram
            </a>
          )}
          <span>© {year}</span>
        </div>
      </div>
    </footer>
  );
}
