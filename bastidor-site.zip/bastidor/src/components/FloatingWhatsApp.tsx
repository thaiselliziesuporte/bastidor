"use client";

import { useEffect, useState } from "react";
import { ChatIcon } from "./ChatIcon";
import { whatsappLink } from "@/content/site";

/**
 * Botão flutuante de WhatsApp. Aparece depois que o visitante passa do topo
 * e some quando a seção de contato está na tela (para não duplicar o CTA).
 */
export function FloatingWhatsApp() {
  const [pastHero, setPastHero] = useState(false);
  const [atContact, setAtContact] = useState(false);

  useEffect(() => {
    const onScroll = () => setPastHero(window.scrollY > window.innerHeight * 0.8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const contact = document.getElementById("contato");
    let io: IntersectionObserver | undefined;
    if (contact && "IntersectionObserver" in window) {
      io = new IntersectionObserver(([entry]) => setAtContact(entry.isIntersecting), { threshold: 0.15 });
      io.observe(contact);
    }
    return () => {
      window.removeEventListener("scroll", onScroll);
      io?.disconnect();
    };
  }, []);

  const visible = pastHero && !atContact;

  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Conversar no WhatsApp"
      tabIndex={visible ? 0 : -1}
      aria-hidden={!visible}
      className={`fixed bottom-5 right-5 z-30 inline-flex h-14 items-center gap-2 rounded-full bg-thread pl-4 pr-5 font-semibold text-white shadow-[0_10px_30px_-10px_rgba(35,39,92,0.55)] transition-all duration-300 hover:bg-thread-dark sm:bottom-7 sm:right-7 ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      }`}
    >
      <ChatIcon />
      <span>WhatsApp</span>
    </a>
  );
}
