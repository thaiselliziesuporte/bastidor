/**
 * Elemento visual do topo: um bastidor de bordado em que um fio vermelho
 * "costura" um balão de conversa. É a metáfora da marca: o atendimento
 * feito com cuidado, ponto a ponto, nos bastidores do seu negócio.
 */
export function HoopArt({ className = "" }: { className?: string }) {
  const bubble =
    "M140 172 H262 Q292 172 292 202 V258 Q292 288 262 288 H180 L136 326 L148 288 H140 Q110 288 110 258 V202 Q110 172 140 172 Z";
  return (
    <svg viewBox="0 0 400 440" role="img" aria-label="Ilustração de um bastidor de bordado com um balão de conversa costurado em linha vermelha" className={className}>
      <defs>
        <pattern id="weave" width="6" height="6" patternUnits="userSpaceOnUse">
          <path d="M0 3h6M3 0v6" stroke="#23275c" strokeOpacity="0.05" strokeWidth="1" />
        </pattern>
        <clipPath id="fabric">
          <circle cx="200" cy="240" r="158" />
        </clipPath>
        <mask id="stitch-mask">
          <path d={bubble} pathLength={1} fill="none" stroke="#fff" strokeWidth="14" className="thread-draw" style={{ ["--len" as string]: 1 }} />
        </mask>
      </defs>

      {/* tecido */}
      <circle cx="200" cy="240" r="158" fill="#ffffff" />
      <rect x="40" y="80" width="320" height="320" fill="url(#weave)" clipPath="url(#fabric)" />

      {/* aro e parafuso do bastidor */}
      <rect x="180" y="50" width="40" height="30" rx="6" fill="#23275c" />
      <rect x="192" y="34" width="16" height="20" rx="3" fill="#3a3f7a" />
      <circle cx="200" cy="240" r="170" fill="none" stroke="#23275c" strokeWidth="14" />
      <circle cx="200" cy="240" r="159" fill="none" stroke="#23275c" strokeOpacity="0.35" strokeWidth="1.5" />

      {/* balão costurado em ponto corrido */}
      <path d={bubble} fill="none" stroke="#b8323f" strokeWidth="5" strokeLinecap="round" strokeDasharray="13 9" mask="url(#stitch-mask)" />

      {/* três pontos em cruz: "digitando..." */}
      <g stroke="#23275c" strokeWidth="3.5" strokeLinecap="round" className="stitch-reveal">
        <path d="M163 222l12 12M175 222l-12 12" />
        <path d="M195 222l12 12M207 222l-12 12" />
        <path d="M227 222l12 12M239 222l-12 12" />
      </g>

      {/* fio solto até a agulha */}
      <path d="M140 172 C 118 120, 90 96, 58 92" fill="none" stroke="#b8323f" strokeWidth="2" strokeLinecap="round" className="stitch-reveal" />
      <g className="stitch-reveal">
        <path d="M58 92 L 20 60" stroke="#5b5e7e" strokeWidth="3" strokeLinecap="round" />
        <ellipse cx="54" cy="88.5" rx="4" ry="1.6" transform="rotate(40 54 88.5)" fill="#fff" stroke="#5b5e7e" strokeWidth="1.2" />
      </g>
    </svg>
  );
}
