"use client";

import { useEffect, useState } from "react";
import { Logo } from "./Logo";
import { ChatIcon } from "./ChatIcon";
import { nav } from "@/content/content";
import { site, whatsappLink } from "@/content/site";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-[background-color,border-color] duration-300 ${
        scrolled || open ? "border-b border-line bg-paper/95 backdrop-blur" : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto flex h-[4.25rem] max-w-6xl items-center justify-between px-5 sm:px-8">
        <a href="#topo" className="flex" aria-label={`${site.brand}, voltar ao início`} onClick={() => setOpen(false)}>
          <Logo name={site.brand} />
        </a>

        <nav aria-label="Principal" className="hidden items-center gap-8 md:flex">
          {nav.map((item) => (
            <a key={item.href} href={item.href} className="text-[0.95rem] text-muted transition-colors hover:text-ink">
              {item.label}
            </a>
          ))}
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-primary !min-h-11 !px-5 text-[0.95rem]">
            <ChatIcon className="h-4 w-4" />
            Fale comigo
          </a>
        </nav>

        <button
          type="button"
          className="-mr-2 flex h-11 w-11 items-center justify-center md:hidden"
          aria-expanded={open}
          aria-controls="menu-mobile"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="relative block h-3 w-6">
            <span className={`absolute left-0 h-[2px] w-6 bg-ink transition-transform duration-300 ${open ? "top-[5px] rotate-45" : "top-0"}`} />
            <span className={`absolute left-0 h-[2px] w-6 bg-ink transition-transform duration-300 ${open ? "top-[5px] -rotate-45" : "top-[10px]"}`} />
          </span>
        </button>
      </div>

      <div
        id="menu-mobile"
        hidden={!open}
        className="h-[calc(100dvh-4.25rem)] overflow-y-auto bg-paper px-5 pb-10 pt-4 md:hidden"
      >
        <nav aria-label="Menu" className="flex flex-col">
          {nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="display border-b border-line py-5 text-[2rem]"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-8 w-full">
          <ChatIcon />
          Conversar no WhatsApp
        </a>
      </div>
    </header>
  );
}
