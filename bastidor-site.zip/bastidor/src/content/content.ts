/**
 * TEXTOS DA PÁGINA
 * ------------------------------------------------------------
 * Todos os textos das seções ficam aqui. Para editar, troque o
 * conteúdo entre aspas. Para incluir um serviço, uma pergunta
 * ou um case, copie um bloco existente e altere.
 */

export const nav = [
  { label: "Serviços", href: "#servicos" },
  { label: "Como funciona", href: "#como-funciona" },
  { label: "Sobre", href: "#sobre" },
  { label: "Dúvidas", href: "#duvidas" },
];

export const hero = {
  headline: "Seu lançamento vende. Quem cuida de quem comprou?",
  subheadline:
    "Atendimento e suporte terceirizado para infoprodutores. Eu respondo seus alunos e clientes no WhatsApp, no Direct e no e-mail, organizo cada conversa e cuido do pós-venda, para você voltar a criar e vender.",
  primaryCta: "Conversar no WhatsApp",
  secondaryCta: "Ver como funciona",
  note: "Proposta sob medida, sem compromisso.",
};

export const problem = {
  title: "A venda acontece. Depois, começam as mensagens.",
  intro:
    "Quem vende curso, mentoria ou comunidade conhece esse momento. O produto está no ar, as vendas entram, e o atendimento vai se acumulando no meio de tudo o que você ainda precisa fazer.",
  items: [
    {
      message: "Comprei ontem e não recebi o acesso.",
      context:
        "Chega às 23h, no meio da gravação de uma aula. Se ninguém responde, vira pedido de reembolso.",
    },
    {
      message: "Ainda tem vaga? Parcela no cartão?",
      context:
        "Uma dúvida de compra no Direct, respondida dois dias depois, quando a pessoa já desistiu.",
    },
    {
      message: "Não acho o módulo 3.",
      context:
        "A mesma pergunta, feita por vinte alunos diferentes, respondida vinte vezes do zero.",
    },
    {
      message: "Sobre o que meus alunos mais perguntam?",
      context:
        "Sem registro das conversas, você não sabe o que se repete nem o que isso diz sobre o seu produto.",
    },
  ],
  closing:
    "Nada disso é falta de esforço. É falta de alguém dedicado ao bastidor.",
};

export const services = {
  title: "O que eu assumo por você",
  intro:
    "Quatro frentes que podem ser contratadas juntas ou separadas. O escopo de cada uma é combinado na proposta, de acordo com o seu produto e o seu volume de mensagens.",
  items: [
    {
      title: "Atendimento nos canais",
      description:
        "WhatsApp, Direct do Instagram e e-mail respondidos com o seu tom de voz e dentro de um padrão combinado.",
      includes: [
        "Dúvidas de quem ainda está decidindo a compra",
        "Envio do link certo, na hora certa",
        "Triagem do que precisa chegar até você",
      ],
    },
    {
      title: "Suporte a alunos e clientes",
      description:
        "Resolvo o que trava a experiência de quem já comprou, antes que vire frustração ou reembolso.",
      includes: [
        "Acesso, senha e navegação na plataforma",
        "Certificados, pedidos e segunda via",
        "Reembolsos e trocas dentro da sua política",
      ],
    },
    {
      title: "Organização e CRM",
      description:
        "Cada conversa registrada e etiquetada, no CRM ou na planilha que você já usa, ou em uma estrutura que eu monto.",
      includes: [
        "Etiquetas por tipo de contato e status",
        "Histórico de cada aluno em um só lugar",
        "Base de respostas prontas, sempre atualizada",
      ],
    },
    {
      title: "Pós-venda e follow-up",
      description:
        "O contato que acontece depois da compra e que faz o aluno usar o produto, concluir e voltar a comprar.",
      includes: [
        "Mensagem de boas-vindas e primeiros passos",
        "Lembretes de aulas ao vivo e encontros",
        "Retorno para quem parou e pesquisa de satisfação",
      ],
    },
  ],
};

export const method = {
  title: "Como funciona, do primeiro contato à rotina",
  intro:
    "Um processo curto e claro, para você saber exatamente o que acontece em cada etapa.",
  steps: [
    {
      title: "Conversa inicial",
      description:
        "Entendo o seu produto, a plataforma, os canais que você usa e quantas mensagens chegam hoje. Pode ser pelo WhatsApp ou por chamada de vídeo.",
    },
    {
      title: "Proposta por escrito",
      description:
        "Você recebe escopo, horários de atendimento, prazo de resposta, o que fica comigo e o que vem para você, e o valor. Tudo antes de começar.",
    },
    {
      title: "Implantação",
      description:
        "Recebo os acessos, escrevo o manual de respostas no seu tom de voz para você aprovar e organizo etiquetas, planilha ou CRM.",
    },
    {
      title: "Atendimento em rotina",
      description:
        "Atendo no dia a dia e envio um relatório periódico com o volume de contatos, as dúvidas que mais se repetem e sugestões de melhoria.",
    },
  ],
};

export const differentials = {
  title: "Por que delegar o atendimento para mim",
  items: [
    {
      title: "Atendimento tratado como processo",
      description:
        "Minha formação é em Engenharia de Produção. Na prática, isso significa padronizar respostas, desenhar fluxos e registrar tudo, para que o atendimento não dependa de memória nem de improviso.",
    },
    {
      title: "Seu tom de voz, documentado",
      description:
        "Antes de responder qualquer aluno, escrevo um manual com as respostas-padrão e a forma como você fala. Você aprova. Seus alunos continuam sentindo que falam com a sua marca.",
    },
    {
      title: "Você enxerga o que acontece",
      description:
        "O relatório mostra quais dúvidas se repetem e onde o aluno trava. Essa informação ajuda a ajustar a página de vendas, a plataforma e o próprio conteúdo.",
    },
    {
      title: "Tudo combinado por escrito",
      description:
        "Horários, prazo de resposta e limites ficam definidos na proposta. Você sabe o que esperar, e eu sei exatamente quando algo precisa chegar até você.",
    },
  ],
};

/**
 * PORTFÓLIO / CASES
 * Enquanto a lista "cases" estiver vazia, a página mostra a demonstração
 * de como o trabalho é entregue. Quando você tiver um case real,
 * adicione um item assim (e a seção passa a exibi-lo):
 *
 * {
 *   client: "Nome do cliente ou do produto",
 *   segment: "Ex.: Curso online de confeitaria",
 *   challenge: "Qual era a situação antes",
 *   work: "O que você fez",
 *   result: "O que mudou (só resultados reais, com autorização do cliente)",
 * },
 */
export const portfolio = {
  title: "Como o trabalho fica na prática",
  intro:
    "Dois exemplos do que você recebe ao contratar: o manual de respostas, escrito antes de começar, e o relatório que acompanha a rotina.",
  disclaimer:
    "Modelos ilustrativos, criados para demonstração. Não representam dados de clientes reais.",
  cases: [] as {
    client: string;
    segment: string;
    challenge: string;
    work: string;
    result: string;
  }[],
};

export const about = {
  title: "Quem cuida do seu bastidor",
  paragraphs: [
    "Sou engenheira de produção, com pós-graduação em Gestão de Projetos, Jornada do Cliente e Metodologias Ágeis. Passei a formação inteira estudando duas coisas: como organizar processos para que funcionem sem depender de esforço heroico, e como o cliente percebe cada contato com uma marca.",
    "É essa combinação que eu levo para o seu atendimento. Trabalho de casa, de forma 100% remota, e atendo um número limitado de clientes ao mesmo tempo para manter a qualidade e a proximidade.",
  ],
  credentials: [
    "Engenharia de Produção",
    "Pós-graduação em Gestão de Projetos",
    "Pós-graduação em Jornada do Cliente",
    "Pós-graduação em Metodologias Ágeis",
    "Fast MBA em Liderança e Gestão de Pessoas",
    "Certificação HubSpot Academy · Sales Hub",
    "Certificação SEBRAE · Atendimento ao Cliente",
  ],
};

export const faq = {
  title: "Perguntas frequentes",
  items: [
    {
      q: "Como funciona a contratação?",
      a: "Começa com uma conversa para eu entender o seu produto e o seu volume de mensagens. Depois envio uma proposta por escrito com escopo, horários, prazo de resposta e valor. Com a proposta aprovada, combinamos a data de início.",
    },
    {
      q: "Quanto custa?",
      a: "O valor depende do escopo: quais canais, quantas mensagens chegam por dia, horários de cobertura e se inclui pós-venda e organização. Por isso não trabalho com tabela fixa. A proposta chega com o valor fechado, sem custos escondidos.",
    },
    {
      q: "Em quais horários você atende?",
      a: "Os horários de cobertura são definidos na proposta, de acordo com o momento do seu negócio. Em um lançamento, por exemplo, a necessidade é diferente de uma semana comum. Fora do horário combinado, deixamos uma mensagem automática informando quando a resposta chega.",
    },
    {
      q: "Em quanto tempo consigo começar?",
      a: "Depois da proposta aprovada, a implantação inclui receber os acessos, escrever o manual de respostas e você aprová-lo. O prazo exato é informado na proposta, porque depende de quantos canais e plataformas entram no escopo.",
    },
    {
      q: "Como é feito o pagamento?",
      a: "A forma e a periodicidade do pagamento são combinadas na proposta e ficam registradas por escrito antes do início do trabalho.",
    },
    {
      q: "Vou precisar te passar a senha das minhas contas?",
      a: "Sempre que a ferramenta permite, uso acesso de equipe ou de colaborador, sem precisar da sua senha pessoal, e você pode revogar quando quiser. Os acessos necessários ficam listados na proposta.",
    },
    {
      q: "E quando o aluno pergunta algo que só eu posso responder?",
      a: "Isso é definido no manual de respostas: o que eu resolvo sozinha e o que encaminho para você, por qual canal e com qual urgência. Você recebe a pergunta já resumida, com o contexto, e eu devolvo a resposta ao aluno.",
    },
    {
      q: "O serviço é personalizado?",
      a: "Sim. Cada infoproduto tem uma plataforma, uma política de reembolso e um jeito de falar com o aluno. O manual de respostas e o escopo são construídos a partir do seu negócio, não de um modelo pronto.",
    },
    {
      q: "Como peço um orçamento?",
      a: "Pelo WhatsApp ou pelo formulário no fim desta página. Conte qual é o seu produto, a plataforma que usa e em quais canais as mensagens chegam. Eu respondo para marcarmos a conversa inicial.",
    },
  ],
};

export const finalCta = {
  title: "Vamos olhar juntos para o seu bastidor?",
  text: "Me conte sobre o seu produto e de onde vêm as mensagens. A primeira conversa serve para entender o que você precisa, sem compromisso de contratação.",
  button: "Conversar no WhatsApp",
  formTitle: "Prefere me adiantar os detalhes?",
  formText:
    "Preencha os campos e o WhatsApp abre com a mensagem já escrita. É só enviar.",
};
