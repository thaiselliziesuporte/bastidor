/**
 * CONFIGURAÇÃO PRINCIPAL DO SITE
 * ------------------------------------------------------------
 * Troque aqui seu nome, WhatsApp, e-mail e o endereço do site.
 * Tudo que estiver marcado com "TROCAR" precisa ser preenchido
 * antes de publicar.
 */

export const site = {
  /** Nome da marca exibido no topo, no rodapé e no título da aba. */
  brand: "Bastidor",
  /** Descrição curta da marca (aparece ao lado do nome no rodapé). */
  tagline: "Suporte e atendimento para infoprodutores",

  /** TROCAR: seu nome como quer que apareça na seção "Sobre". */
  ownerName: "Thais Elliziê",
  /** TROCAR: suas iniciais (usadas no lugar da foto, enquanto não houver uma). */
  ownerInitials: "TE",
  /**
   * Foto de perfil (opcional). Coloque o arquivo em /public (ex.: /public/foto.jpg)
   * e escreva aqui "/foto.jpg". Deixe vazio para mostrar as iniciais.
   */
  ownerPhoto: "",

  /**
   * TROCAR: WhatsApp só com números, com 55 + DDD.
   * Exemplo: 71 99999-9999  ->  "5571999999999"
   */
  whatsapp: "5577999267036",
  /** Mensagem que já aparece escrita quando o visitante abre o WhatsApp. */
  whatsappMessage:
    "Olá! Vi sua página e quero conversar sobre suporte para o meu infoproduto.",

  /** TROCAR (opcional): e-mail de contato exibido no rodapé. Deixe vazio para ocultar. */
  email: "thaissuporte@gmail.com",
  /** TROCAR (opcional): link do seu Instagram. Deixe vazio para ocultar. */
  instagram: "",

  /** Região de atendimento exibida no rodapé. */
  location: "Bahia, Brasil · atendimento 100% remoto",

  /**
   * TROCAR depois de publicar: endereço final do site, sem barra no fim.
   * Ex.: "https://bastidor.vercel.app" ou "https://www.seudominio.com.br"
   */
  url: "https://bastidor.vercel.app",

  seo: {
    title: "Bastidor · Suporte e atendimento para infoprodutores",
    description:
      "Atendimento terceirizado para infoprodutores: WhatsApp, Direct e e-mail respondidos no seu tom, suporte a alunos, organização das conversas e pós-venda.",
  },
} as const;

/** Monta o link do WhatsApp com uma mensagem pronta. */
export function whatsappLink(message: string = site.whatsappMessage) {
  return `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`;
}
