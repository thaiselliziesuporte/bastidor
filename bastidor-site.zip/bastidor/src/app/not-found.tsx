export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-2xl flex-col justify-center px-5 sm:px-8">
      <h1 className="display text-[2.6rem]">Esta página não existe.</h1>
      <p className="mt-4 text-muted">O endereço pode ter mudado. Volte para o início para ver os serviços.</p>
      <a href="/" className="btn btn-primary mt-8 self-start">Ir para o início</a>
    </main>
  );
}
