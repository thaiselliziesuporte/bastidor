import { Header } from "@/components/Header";
import { FloatingWhatsApp } from "@/components/FloatingWhatsApp";
import { About, Differentials, FaqSection, FinalCta, Footer, Hero, Method, Portfolio, Problem, Services } from "@/components/Sections";

/**
 * Ordem das seções da página. Para remover ou reordenar uma seção,
 * basta mover ou apagar a linha correspondente.
 */
export default function Home() {
  return (
    <>
      <Header />
      <main id="conteudo">
        <Hero />
        <Problem />
        <Services />
        <Method />
        <Differentials />
        <Portfolio />
        <About />
        <FaqSection />
        <FinalCta />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
