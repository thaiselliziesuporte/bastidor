import type { Metadata } from "next";
import { Logo } from "@/components/Logo";
import { site } from "@/content/site";
import { ReopenWhatsApp } from "./ReopenWhatsApp";

export const metadata: Metadata = {
  title: `Mensagem pronta · ${site.brand}`,
  robots: { index: false, follow: false },
};

export default function Obrigado() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-2xl flex-col px-5 py-10 sm:px-8">
      <a href="/" aria-label={`${site.brand}, voltar ao início`}>
        <Logo name={site.brand} />
      </a>
      <div className="my-auto py-16">
        <h1 className="display text-[2.6rem] sm:text-[3.6rem]">Sua mensagem está pronta no WhatsApp.</h1>
        <p className="mt-6 max-w-[50ch] text-[1.1rem] text-muted">
          Falta só um toque: confira o texto e toque em enviar. Assim que ela chegar, eu respondo para marcarmos a conversa inicial.
        </p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <ReopenWhatsApp />
          <a href="/" className="btn btn-ghost">Voltar para a página</a>
        </div>
      </div>
    </main>
  );
}
