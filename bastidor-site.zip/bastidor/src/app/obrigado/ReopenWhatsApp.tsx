"use client";

import { useEffect, useState } from "react";
import { whatsappLink } from "@/content/site";
import { ChatIcon } from "@/components/ChatIcon";

/** Reabre o WhatsApp com a mensagem do formulário, caso não tenha aberto. */
export function ReopenWhatsApp() {
  const [href, setHref] = useState(whatsappLink());
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem("bastidor:wa");
      if (saved) setHref(saved);
    } catch {}
  }, []);
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
      <ChatIcon />
      O WhatsApp não abriu? Toque aqui
    </a>
  );
}
